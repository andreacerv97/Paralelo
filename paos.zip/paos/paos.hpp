//
// Created by Guillermo Rodriguez on 17/10/2021.
//

#ifndef AOS_FN_AOS_HPP
#define AOS_FN_AOS_HPP

const double G = 6.674e-11;

struct vect{    //for the x,y and z components of our objects

    double x;   
    double y;
    double z;
};

struct Objects{

    vect pos;   //defines the position of the object
    vect vel;   //defines the velocity of the object
    vect acc;   //defines de acceleration of the object
    double m;   //defines the mass of the object
    int flag;   // 1 if the object exists, when it is merged into another it goes into 0
};


//with this function we calculate the euclidean distance between 2 objects
double distance(Objects obj1, Objects obj2){ 
    
    double dis=std::sqrt((obj1.pos.x - obj2.pos.x)*(obj1.pos.x - obj2.pos.x)+(obj1.pos.y - obj2.pos.y)*(obj1.pos.y - obj2.pos.y)+(obj1.pos.z - obj2.pos.z)*(obj1.pos.z - obj2.pos.z));
    return dis;
}

//function to calculate the gravity force of each object
void grav_it(Objects *objs, vect **Forces, long int num_objects){

    double coefficient;
#pragma omp parallel for
    for (int i = 0; i < num_objects; ++i){ //we make them 0 because the force one object ejerces to itself is 0
        Forces[i][i].x= 0;  
        Forces[i][i].y = 0;
        Forces[i][i].z = 0;
#pragma omp parallel for
        //we compute the gravity force for each pair of elements in the simulation
        for(int j = i; j < num_objects; ++j){ 
            if ((j != i) && (objs[i].flag) && (objs[j].flag)){
                coefficient=(G*objs[i].m*objs[j].m)/((distance(objs[i], objs[j]))*(distance(objs[i], objs[j]))*(distance(objs[i], objs[j])));
                Forces[i][j].x = coefficient*(objs[j].pos.x - objs[i].pos.x);
                Forces[j][i].x = - Forces[i][j].x;
                Forces[i][j].y = coefficient*(objs[j].pos.y - objs[i].pos.y);
                Forces[j][i].y = - Forces[i][j].y;
                Forces[i][j].z = coefficient*(objs[j].pos.z - objs[i].pos.z);
                Forces[j][i].z = - Forces[i][j].z;
            }
        }
    }
}


//in this function we calculate the acceleration, velocity and position of each object
void pos_it(Objects *objs, vect **Forces, long int num_objects, double time_step,double size_enclosure){
#pragma omp parallel for
    for(int i = 0; i < num_objects; ++i){
                if(objs[i].flag){ //if the object exists
                    double sumx=0;
                    double sumy=0;
                    double sumz=0;
                    for(int j = 0; j < num_objects; ++j){
                        if(objs[j].flag){
                            sumx += Forces[i][j].x;
                            sumy += Forces[i][j].y;
                            sumz += Forces[i][j].z;
                            }
                    }
                    //acceleration
                    //we make use of the formula: Force = mass * acceleration
                    objs[i].acc.x = sumx/objs[i].m;
                    objs[i].acc.y = sumy/objs[i].m;
                    objs[i].acc.z = sumz/objs[i].m;
                    //velocity
                    objs[i].vel.x = objs[i].vel.x + objs[i].acc.x * time_step;
                    objs[i].vel.y = objs[i].vel.y + objs[i].acc.y * time_step;
                    objs[i].vel.z = objs[i].vel.z + objs[i].acc.z * time_step;
                    //position
                    objs[i].pos.x = objs[i].pos.x + objs[i].vel.x * time_step;
                    objs[i].pos.y = objs[i].pos.y + objs[i].vel.y * time_step;
                    objs[i].pos.z = objs[i].pos.z + objs[i].vel.z * time_step;

                    //once we have the position, we check for any object out of bounds (rebound)
                    if (objs[i].pos.x <= 0) {
                        objs[i].pos.x = 0;
                        objs[i].vel.x = -objs[i].vel.x;
                    }

                    if (objs[i].pos.y <= 0) {
                        objs[i].pos.y = 0;
                        objs[i].vel.y = -objs[i].vel.y;
                    }

                    if (objs[i].pos.z <= 0) {
                        objs[i].pos.z = 0;
                        objs[i].vel.z = -objs[i].vel.z;
                    }

                    if (objs[i].pos.x >= size_enclosure) {
                        objs[i].pos.x = size_enclosure;
                        objs[i].vel.x = -objs[i].vel.x;
                    }

                    if (objs[i].pos.y >= size_enclosure) {
                        objs[i].pos.y = size_enclosure;
                        objs[i].vel.y = -objs[i].vel.y;
                    }

                    if (objs[i].pos.z >= size_enclosure) {
                        objs[i].pos.z = size_enclosure;
                        objs[i].vel.z = -objs[i].vel.z;
                    }


                }
            }
}



#endif //AOS_FN_AOS_HPP
